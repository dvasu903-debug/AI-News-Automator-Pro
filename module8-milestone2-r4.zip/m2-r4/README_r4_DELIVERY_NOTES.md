# Module 8 Milestone 2 — r4 Package (Post-Compatibility-Audit Rewrite)

## What this is

r3 (post-Module-3-compatibility-audit rewrite) plus one owner-directed
constraint applied: `approval_mode` is no longer validated against an
invented `{manual, auto}` enum. Everything else is unchanged from r3.
File paths mirror the real repo exactly (`src/Publishing/...`,
`tests/Publishing/...`) so this can be applied as a direct merge.

**Nothing in `src/Storage/` was touched.** All fixes are confined to
Publishing's own files.

## Not executed — read this first

No PHP runtime is available in the environment that produced this
package. Every change was verified by reading the real source files
line by line, not by running `php -l`, PHPUnit, or PHPCS. Treat every
file here as **design-verified, not execution-verified** until it
actually runs in your environment — see the accompanying verification
runbook for the commands to do that.

## r4 change: approval_mode is opaque (owner constraint)

`PublishingProfileValidator` no longer enforces `ALLOWED_APPROVAL_MODES`.
`approval_mode` is validated structurally only: non-empty, within the
column's `VARCHAR(30)` width. No fixed value list is introduced unless
one already exists elsewhere in the repository or is approved via ADR.
`PublishingProfileValidatorTest` updated accordingly (`test_arbitrary_
non_empty_approval_mode_passes` now asserts that unrecognized values
like `'review_queue'` pass, proving there's no hidden enum left behind).

## The eight approved r3 changes (unchanged, carried forward)

1. **Namespace**: `AINewsAutomatorPro\` → `AINewsAutomator\` everywhere.
2. **Repository rewritten** against the real `ConnectionInterface`/
   `QueryBuilderInterface`.
3. **Extends `AbstractRepository`**, matching `QueueRepository`/
   `DraftRepository`'s established pattern.
4. **`TransactionManagerInterface` injected separately** from
   `ConnectionInterface`.
5. **`is_active` → `enabled`** throughout.
6. **`Filter`/`SortOrder` value objects** replace assumed builder calls.
7. **`workflow_key`, `vertical`, `approval_mode` preserved** as real DTO
   fields, replacing the invented `post_type` concept.
8. **DTO and repository realigned** to the approved schema while
   keeping the Milestone 2 architecture (Validator → Service →
   Repository, policies P1–P4, single-writer `is_default`, exception
   taxonomy).

## New migration (approved architectural decision, unchanged from r3)

`Migration_20260722100004_AddIsDefaultToPublishingProfilesTable` adds
`is_default TINYINT(1) NOT NULL DEFAULT 0` plus a supporting index,
additive-only against the frozen Milestone 1 migration. Registered as
the fourth entry in `PublishingMigrationManifest`.

## Known limitation — tracked as technical debt, not fixed here (owner directive)

`tests/Storage/FakeWpdb.php`'s `applyWhere()` doesn't support the `!=`
operator `Filter::notEquals()` generates, so
`existsWithSlug()`/`existsWithName()`'s `$excludeId` path can't be
verified against it. Per your instruction this stays as-is —
`PublishingProfileRepositoryTest::test_exists_with_slug_exclude_id_needs_real_mysql_verification()`
remains a `markTestIncomplete()` with the reason recorded in the test.
This should be logged in the handbook's Technical Debt Register (Part
XII) at freeze, not solved inside Publishing. Coverage gap is closed by
Hostinger runtime validation instead (checklist item D7).

## Test coverage (unexecuted, see above)

- `PublishingProfileTest` — 12 DTO tests.
- `PublishingProfileValidatorTest` — 12 tests (one enum test pair
  replaced by structural-only tests; net effect: same rule count, no
  fixed value list).
- `PublishingProfileServiceTest` — 17 tests, unchanged from r3.
- `PublishingProfileRepositoryTest` — 17 tests against the real
  `Connection`/`TransactionManager`/`FakeWpdb`, unchanged from r3,
  including the one documented incomplete test.

## Not in scope for this pass

Container identity probe (`spl_object_id()` twice-resolve check) and
`docs/verification/authorized-frozen-changes.txt` update — both require
a running environment / are freeze-time bookkeeping, not code changes.
