# Module 8 Milestone 2 — r4 Verification Runbook

This is not a report of results — it's the exact sequence to run in
your real environment, matched to the six-item pipeline you specified.
Paste the actual output back and the Freeze Report gets built from
that, not from this runbook.

## 0. Merge

This session has no access to your actual repository (only the
snapshot you uploaded as `SOURCE-for-build-18.zip`), so "merge into the
working repository" has to happen on your end. From the r4 package:

```bash
# From your repo root:
cp -r r4/src/Publishing/. src/Publishing/
cp -r r4/tests/Publishing/. tests/Publishing/
```

This is a straight overlay — every file in the r4 package already
mirrors the real repo's path exactly, and nothing outside
`src/Publishing/`/`tests/Publishing/` is touched. Diff before
overwriting if you want an explicit before/after:

```bash
diff -ru src/Publishing r4/src/Publishing
diff -ru tests/Publishing r4/tests/Publishing
```

## 1. PHP syntax validation

```bash
find src/Publishing tests/Publishing -name '*.php' -print0 | xargs -0 -n1 php -l
```

Expect `No syntax errors detected` for all 20 files. Any failure here
means I made a real mistake — paste the exact error and file/line back.

## 2. PHPUnit

```bash
composer test
# equivalent to: vendor/bin/phpunit
```

Or scoped to just this milestone while iterating:

```bash
vendor/bin/phpunit --filter Publishing
```

Expect 58 tests across the four Publishing test files (12 + 12 + 17 +
17), with exactly **one** reported as incomplete —
`PublishingProfileRepositoryTest::test_exists_with_slug_exclude_id_needs_real_mysql_verification`
— not a failure. Any other failure is a real defect in this package;
paste the full PHPUnit output.

## 3. PHPCS

```bash
composer lint
# equivalent to: phpcs --standard=phpcs.xml.dist src/Publishing
```

Also worth running against the tests directory, since the ruleset's
policy note (empirically-verified formatting: 4-space indent, short
array syntax, Allman braces) should apply there too even though the
composer script only targets `src/`:

```bash
phpcs --standard=phpcs.xml.dist tests/Publishing
```

## 4. Static analysis

No PHPStan config exists in the repository (confirmed during the
Phase 3 composer review) — there's nothing to run yet. If you want
static analysis in the pipeline before freeze, that's a new tooling
decision (config + target level), not a Milestone 2 code fix. Flagging
rather than silently skipping.

## 5. Migration verification

```bash
wp eval 'AINewsAutomator\Storage\Migrations\MigrationRunner::class;' # sanity: class autoloads
```

More concretely, against a real WordPress + MySQL install (this is
where dbDelta's diff behavior actually gets exercised — nothing in
step 1–3 touches a database):

1. Activate/reactivate the plugin, or trigger the `plugins_loaded`
   self-healing check, so `PublishingMigrationManifest::migrations()`
   runs including the new `Migration_20260722100004_...`.
2. Confirm the column exists:
   ```sql
   SHOW COLUMNS FROM wp_ana_publishing_profiles LIKE 'is_default';
   -- expect: is_default | tinyint(1) | NO | | 0 |
   ```
3. Confirm the pre-existing UNIQUE index on `slug` is untouched:
   ```sql
   SHOW INDEX FROM wp_ana_publishing_profiles WHERE Key_name = 'slug';
   ```
4. Confirm no data loss: row count before/after should be identical if
   any test/seed profiles already existed.

## 6. Runtime verification (container wiring)

The identity probe from `MILESTONE_2_FREEZE_CHECKLIST.md` item C —
confirms the Module 7 `bind()`/`singleton()` defect class doesn't
recur here:

```php
// One-off eval, e.g. via `wp eval-file` or a mu-plugin snippet:
$a = $container->get(\AINewsAutomator\Publishing\Contracts\PublishingProfileRepositoryInterface::class);
$b = $container->get(\AINewsAutomator\Publishing\Contracts\PublishingProfileRepositoryInterface::class);
var_dump(spl_object_id($a) === spl_object_id($b)); // must be true
```

Repeat for `PublishingProfileService::class`.

## After steps 1–6 above: the full Hostinger checklist

Once local verification (steps 1–4) is clean, proceed through
`MILESTONE_2_FREEZE_CHECKLIST.md` items D6–D14 in full (CRUD cycle,
utf8mb4/emoji round-trip, `markDefault()` transaction + concurrent
switching, transaction rollback probe, `requireDefault()` failure path,
policy checks live) on the actual Hostinger environment. That checklist
is unchanged by r4 and remains the authoritative sequence — this
runbook's step 6 duplicates only the identity-probe item since it's
cheap enough to also sanity-check locally first.

## What I need back to write the real Freeze Report

Paste (or attach) the actual output of steps 1–3 at minimum, plus a
summary of the Hostinger checklist results (pass/fail per item, and the
exact error text for anything that fails). I'll turn that into the
Milestone 2 Freeze Report your instruction asked for — built from what
actually happened, not from what was expected to happen.
